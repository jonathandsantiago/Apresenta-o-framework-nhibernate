﻿using Framework.Data.Nhibernate;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using NHibernate;

namespace Apresentacao
{
    public class Startup
    {
        private ISessionFactory sessionFactory;
        private AppSessionFactory appSessionFactory;

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            appSessionFactory = new AppSessionFactory(Configuration, true);
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            sessionFactory = appSessionFactory.GetFactory();
            services.AddSingleton<AppSessionFactory>();
            services.AddScoped(c => sessionFactory);
            services.AddMvc();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseBrowserLink();
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}